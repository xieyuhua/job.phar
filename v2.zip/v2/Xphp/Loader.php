<?php

//tsx 注册自动加载php文件函数

spl_autoload_register(function ($name){
    $name = str_replace('\\',DIRECTORY_SEPARATOR, $name);
    $namespace = explode('/', $name);
    switch ($namespace[0]) {
        case 'think':
           $name = 'Xphp'.DIRECTORY_SEPARATOR.$name;
            break;
            
        case 'Kcloze':
           $name = 'Xphp'.DIRECTORY_SEPARATOR.$name;
            break;
            
        case 'Symfony':
            $name = 'Xphp'.DIRECTORY_SEPARATOR.$name;
            break;
			
        case 'Bramus':
           $name = 'Xphp'.DIRECTORY_SEPARATOR.'Router'.DIRECTORY_SEPARATOR.$name;
            break; 
			
        default:
            $name = $name;
            break;
    }
    $file = $name.'.php';
	
    if(is_file($file)) include_once $file;
});

